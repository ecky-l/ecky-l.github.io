requirejs.config({
    baseUrl: 'js'
});

